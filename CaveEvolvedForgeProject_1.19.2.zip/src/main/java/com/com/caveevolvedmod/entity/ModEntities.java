package com.caveevolvedmod.entity;

import com.caveevolvedmod.MyMod;
import com.caveevolvedmod.entity.custom.CaveEvolvedEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.core.registries.Registries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITIES, MyMod.MODID);
    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, MyMod.MODID);

    public static final RegistryObject<EntityType<CaveEvolvedEntity>> CAVE_EVOLVED =
        ENTITIES.register("cave_evolved", () ->
            EntityType.Builder.of(CaveEvolvedEntity::new, MobCategory.MONSTER)
                .sized(0.9f, 2.2f)
                .build(new ResourceLocation(MyMod.MODID, "cave_evolved").toString()));

    public static final RegistryObject<SpawnEggItem> CAVE_EVOLVED_SPAWN_EGG =
        ITEMS.register("cave_evolved_spawn_egg", () ->
            new SpawnEggItem(CAVE_EVOLVED.get(), 0x3A2D0E, 0xA0A0A0, new Item.Properties()));
}
