package com.caveevolvedmod;

import com.caveevolvedmod.entity.ModEntities;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.world.BiomeLoadingEvent;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.biome.MobSpawnSettings;

@Mod("cave_evolved")
public class MyMod {
    public static final String MODID = "cave_evolved";

    public MyMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        MinecraftForge.EVENT_BUS.addListener(this::onBiomeLoad);
    }

    private void onBiomeLoad(BiomeLoadingEvent event) {
        if (event.getName() != null && event.getName().toString().contains("cave")) {
            event.getSpawns().getSpawner(MobCategory.MONSTER).add(
                new MobSpawnSettings.SpawnerData(ModEntities.CAVE_EVOLVED.get(), 80, 1, 2));
        }
    }
}
