package com.caveevolvedmod.entity;

import com.caveevolvedmod.MyMod;
import com.caveevolvedmod.entity.custom.CaveEvolvedEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITIES, MyMod.MODID);

    public static final RegistryObject<EntityType<CaveEvolvedEntity>> CAVE_EVOLVED =
        ENTITIES.register("cave_evolved", () ->
            EntityType.Builder.of(CaveEvolvedEntity::new, MobCategory.MONSTER)
                .sized(0.9f, 2.2f)
                .build(new ResourceLocation(MyMod.MODID, "cave_evolved").toString()));
}
