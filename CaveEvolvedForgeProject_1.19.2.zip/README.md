# Cave Evolved Mod (Forge 1.19.2)

这是一个基于 Minecraft Forge 1.19.2 的模组开发项目，已集成 GeckoLib 动画库作为前置依赖。

## ✅ 环境要求

- Java 17
- Minecraft Forge MDK 1.19.2 (版本 43.2.0)
- Gradle（推荐使用项目自带的 Wrapper）

## 📁 项目结构说明

```
.
├── build.gradle           // 构建配置
├── settings.gradle        // 项目名定义
├── src/
│   └── main/
│       ├── java/          // 你的 mod Java 代码
│       └── resources/     // assets, sounds, lang 等资源
```

## ⚙️ 构建方法

### Linux/macOS:

```bash
./gradlew build
```

### Windows:

```bat
gradlew.bat build
```

构建完成后，mod 文件会出现在：

```
build/libs/caveevolvedmod-1.0.jar
```

## 🧩 前置依赖

请确保在运行本模组之前，已安装 GeckoLib（1.19.2 对应版本）：

- [GeckoLib Forge 1.19.2 下载页面](https://www.curseforge.com/minecraft/mc-mods/geckolib)

## 📦 适配说明

- Minecraft 版本：**1.19.2**
- Forge 版本：**43.2.0**
- Java 版本：**17**
- GeckoLib：**geckolib3**，版本 >= 3.1.40

---

作者：qwmike1145